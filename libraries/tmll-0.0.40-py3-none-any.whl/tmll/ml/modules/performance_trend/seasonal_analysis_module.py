from typing import Literal, Dict, Any, Optional
import pandas as pd
import numpy as np
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.stattools import acf, pacf
import matplotlib.pyplot as plt

from tmll.ml.modules.base_module import BaseModule
from tmll.tmll_client import TMLLClient
from tmll.ml.modules.common.data_fetch import DataFetcher
from tmll.ml.modules.common.data_preprocess import DataPreprocessor
from tmll.common.models.output import Output

TARGET_OUTPUTS = [
    Output.from_dict({
        "name": "Histogram",
        "id": "org.eclipse.tracecompass.internal.tmf.core.histogram.HistogramDataProvider",
        "type": "TREE_TIME_XY"
    })
]

class SeasonalAnalysis(BaseModule):
    """
    A module for performing seasonal analysis on time series data.

    This class provides methods for data fetching, preprocessing, and analyzing
    seasonal patterns in time series data. It includes functionality for
    automatic parameter optimization and various plotting capabilities.
    """

    def __init__(self, client: TMLLClient):
        """
        Initialize the SeasonalAnalysis module.

        :param client: The TMLL client for data access.
        """
        super().__init__(client=client)
        self.data_fetcher = DataFetcher(client)
        self.data_preprocessor = DataPreprocessor()
        self.dataframe = pd.DataFrame()
        self.analysis_results = {}
        self.optimal_params = {}

    def process(self, seasonality: Optional[int] = None, max_lag: Optional[int] = None, resample_frequency: Optional[str] = None, force_reload: bool = False, **kwargs) -> None:
        """
        Process the data for seasonal analysis with automatic parameter optimization.

        :param seasonality: The seasonality to use for decomposition. If None, it will be optimized.
        :param max_lag: The maximum lag for autocorrelation. If None, it will be optimized.
        :param resample_frequency: The frequency to resample the data. If None, it will be optimized.
        :param force_reload: If True, forces data reloading.
        :param kwargs: Additional keyword arguments for parameter optimization.
        """
        # Reset the analysis results
        self.analysis_results = {}
        self.optimal_params = {}

        if self.dataframe.empty or force_reload:
            self.logger.info("Fetching and preprocessing data...")
            data = self.data_fetcher.fetch_data(TARGET_OUTPUTS)
            if data is None:
                self.logger.error("No data fetched")
                return
            self.dataframe = self.data_preprocessor.normalize(data)
            self.dataframe['timestamp'] = pd.to_datetime(self.dataframe['timestamp'], unit='ns')
            self.dataframe.set_index('timestamp', inplace=True)

        if not resample_frequency:
            min_frequency = kwargs.get('min_resample_frequency', '25ms')
            resample_frequency = self._optimize_sampling_frequency(self.dataframe.index, min_frequency) # type: ignore
        self.logger.info(f"Resampling data to {resample_frequency}...")
        self.dataframe = self.data_preprocessor.resample(self.dataframe, frequency=resample_frequency)

        self.logger.info("Performing seasonal analysis...")
        for column in self.dataframe.columns:
            if not seasonality:
                min_seasonality = kwargs.get('min_seasonality', 1)
                seasonality = self._optimize_seasonality(self.dataframe[column], min_seasonality)
            if not max_lag:
                threshold = kwargs.get('lag_threshold', 0.2)
                min_lag = kwargs.get('min_lag', 1)
                max_lag = self._optimize_max_lag(self.dataframe[column], threshold, min_lag)

            self.optimal_params[column] = {
                'seasonality': seasonality,
                'max_lag': max_lag
            }
            
            self.analysis_results[column] = self._analyze_column(
                series=self.dataframe[column],
                seasonality=seasonality,
                max_lag=max_lag
            )

        self.logger.info("Seasonal analysis completed.")

    def _optimize_sampling_frequency(self, timestamp_index: pd.DatetimeIndex, min_frequency: str = '25ms') -> str:
        """
        Optimize the sampling frequency based on the timestamp index.

        :param timestamp_index: The DatetimeIndex of the dataframe.
        :param min_frequency: The minimum allowed frequency.
        :return: Optimal sampling frequency as a string (e.g., '25ms', '1s', '1min').
        """
        deltas = timestamp_index.to_series().diff().dropna()
        mode_delta = deltas.mode()[0]
        
        if isinstance(mode_delta, pd.Timedelta):
            mode_delta_seconds = mode_delta.total_seconds()
            min_ms = pd.Timedelta(min_frequency).total_seconds()

            if mode_delta_seconds < min_ms:
                return '25ms'
            elif mode_delta_seconds < 1:
                return f'{max(int(mode_delta_seconds * 1000), 25)}ms'
            elif mode_delta_seconds < 60:
                return f'{int(mode_delta_seconds)}s'
            elif mode_delta_seconds < 3600:
                return f'{int(mode_delta_seconds // 60)}min'
            elif mode_delta_seconds < 86400:
                return f'{int(mode_delta_seconds // 3600)}h'
            else:
                return f'{int(mode_delta_seconds // 86400)}d'
        else:
            return '25ms'

    def _optimize_seasonality(self, series: pd.Series, min_seasonality: int = 1) -> int:
        """
        Optimize the seasonality parameter for a given time series.

        :param series: The time series to analyze.
        :param min_seasonality: The minimum allowed seasonality.
        :return: Optimal seasonality value.
        """
        acf_values = acf(series.dropna(), nlags=min(len(series)//2, 1000))
        acf_diff = np.diff(acf_values)
        peaks = np.where((acf_diff[:-1] > 0) & (acf_diff[1:] < 0))[0] + 1
        
        if len(peaks) > 0:
            return max(min_seasonality, peaks[0])
        else:
            return 1

    def _optimize_max_lag(self, series: pd.Series, threshold: float = 0.2, min_lag: int = 1) -> int:
        """
        Optimize the max_lag parameter for a given time series.

        :param series: The time series to analyze.
        :param threshold: The significance threshold for PACF.
        :param min_lag: The minimum allowed lag.
        :return: Optimal max_lag value.
        """
        pacf_values = pacf(series.dropna(), nlags=min(len(series)//2, 1000))
        significant_lags = np.where(np.abs(pacf_values) < threshold)[0]
        
        if len(significant_lags) > 0:
            return max(min_lag, significant_lags[0])
        else:
            return min(len(series)//2, 1000)

    def _analyze_column(self, series: pd.Series, seasonality: int, max_lag: int, acf_threshold: float = 0.2) -> Dict[str, Any]:
        """
        Analyze a single column for seasonality.

        :param series: The time series to analyze.
        :param seasonality: The seasonality to use for decomposition.
        :param max_lag: The maximum lag for autocorrelation.
        :param acf_threshold: The threshold for identifying potential seasons.
        :return: A dictionary containing analysis results.
        """
        results = {}
        
        decomposition = seasonal_decompose(series, model='additive', period=seasonality)
        results['decomposition'] = decomposition
        
        detrended = series - decomposition.trend
        deseasonalized = series - decomposition.seasonal
        trend_strength = 1 - np.var(detrended) / np.var(series)
        seasonal_strength = 1 - np.var(deseasonalized) / np.var(detrended)
        results['trend_strength'] = trend_strength
        results['seasonal_strength'] = seasonal_strength
        
        acf_values = acf(series, nlags=max_lag)
        potential_seasons = [i for i in range(1, len(acf_values)) if acf_values[i] > acf_threshold]
        results['acf_values'] = acf_values
        results['potential_seasons'] = potential_seasons
        
        return results

    def plot(self, column: Optional[str] = None, plot_type: Literal['decomposition', 'acf', 'overview'] = 'overview') -> None:
        """
        Plot the analysis results.

        :param column: The specific column to plot. If None, plots all columns.
        :param plot_type: The type of plot to generate ('decomposition', 'acf', or 'overview').
        """
        if not self.analysis_results:
            self.logger.error("No analysis results available. Run process() first.")
            return

        columns_to_plot = [column] if column else list(self.analysis_results.keys())

        for col in columns_to_plot:
            if col not in self.analysis_results:
                self.logger.warning(f"No analysis results found for {col}")
                continue

            if plot_type == 'decomposition':
                self._plot_decomposition(col)
            elif plot_type == 'acf':
                self._plot_acf(col)
            elif plot_type == 'overview':
                self._plot_overview(col)
            else:
                self.logger.error(f"Unknown plot type: {plot_type}")

    def _plot_decomposition(self, column: str) -> None:
        """
        Plot the seasonal decomposition for a column.

        :param column: The column name to plot.
        """
        decomposition = self.analysis_results[column]['decomposition']

        components = ['observed', 'trend', 'seasonal', 'resid']
        titles = [column, 'Trend', 'Seasonal', 'Residual']

        for component, title in zip(components, titles):
            plot_data = pd.DataFrame({
                'timestamp': getattr(decomposition, component).index,
                'value': getattr(decomposition, component).values
            })

            self._plot(plots = [{
                        'plot_type': 'time_series',
                        'data': plot_data,
                        'label': title,
                        'x': 'timestamp',
                        'y': 'value',
                        'color': 'blue',
                        'alpha': 0.7
                    }],
                    plot_size=(15, 3.5),
                    fig_title=title,
                    fig_xlabel='Time',
                    fig_ylabel='Value',
                    legend=False)

    def _plot_acf(self, column: str) -> None:
        """
        Plot the autocorrelation function for a column.

        :param column: The column name to plot.
        """
        acf_values = self.analysis_results[column]['acf_values']
        potential_seasons = self.analysis_results[column]['potential_seasons']

        plot_data = pd.DataFrame({
            'lag': range(len(acf_values)),
            'acf': acf_values
        })

        plots = [{
            'plot_type': 'bar',
            'data': plot_data,
            'x': 'lag',
            'y': 'acf',
            'color': 'blue',
            'alpha': 0.7
        }]

        for season in potential_seasons:
            plots.append({
                'plot_type': 'vline',
                'data': None,
                'x': season,
                'color': 'red',
                'alpha': 0.5,
                'linestyle': '--'
            })

        self._plot(plots,
                   plot_size=(15, 6),
                   fig_title=f'Autocorrelation Function for {column}',
                   fig_xlabel='Lag',
                   fig_ylabel='Autocorrelation')

    def _plot_overview(self, column: str) -> None:
        """
        Plot an overview of the analysis results for a column.

        :param column: The column name to plot.
        """
        results = self.analysis_results[column]
        decomposition = self.analysis_results[column]['decomposition']
        plots = []

        components = ['observed', 'trend', 'seasonal']
        labels = ['Original', 'Trend', 'Seasonal']
        colors = ['blue', 'orange', 'green']
        alphas = [0.6, 1, 0.8]

        for component, label, color, alpha in zip(components, labels, colors, alphas):
            plot_data = pd.DataFrame({
                'timestamp': getattr(decomposition, component).index,
                'value': getattr(decomposition, component).values
            })
            plots.append({
                'plot_type': 'time_series',
                'data': plot_data,
                'label': label,
                'x': 'timestamp',
                'y': 'value',
                'color': color,
                'alpha': alpha
            })

        num_seasons = len(results['potential_seasons'])
        season_colors = plt.get_cmap('rainbow', num_seasons)
        seasonality = self.optimal_params[column]['seasonality']

        for idx, season in enumerate(results['potential_seasons']):
            if (season * seasonality + seasonality) >= len(results['decomposition'].observed):
                break
            start = results['decomposition'].observed.index[season * seasonality]
            end = results['decomposition'].observed.index[season * seasonality + seasonality]
            plots.append({
                'plot_type': 'span',
                'data': None,
                'start': start,
                'end': end,
                'color': season_colors(idx / num_seasons),
                'alpha': 0.25,
                'label': 'Seasons'
            })

        self._plot(plots,
                   plot_size=(15, 3.5),
                   fig_title=f'Overview of {column}',
                   fig_xlabel='Time',
                   fig_ylabel='Value')