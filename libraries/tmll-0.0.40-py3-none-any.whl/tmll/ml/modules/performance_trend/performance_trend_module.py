

from tmll.ml.modules.base_module import BaseModule
from tmll.common.models.experiment import Experiment
from tmll.common.models.output import Output
from tmll.tmll_client import TMLLClient

class PerformanceTrendModule(BaseModule):
    """A class to represent a performance trend module.

    Attributes:
        client (TMLLClient): The TMLL client to use.
        experiment (Experiment): The experiment to analyze.
        outputs (List[Output]): The list of outputs to analyze.
    """

    def __init__(self, client: TMLLClient, experiment: Experiment) -> None:
        """
        Initialize the performance trend module with the given TMLL client and experiment.

        :param client: The TMLL client to use
        :type client: TMLLClient
        :param experiment: The experiment to analyze
        :type experiment: Experiment
        """
        super().__init__(client=client, experiment=experiment)

        self.experiment = experiment

    