from typing import Optional, List, Dict, Tuple
from dataclasses import dataclass
from collections import defaultdict
import numpy as np
import matplotlib.pyplot as plt

from tmll.common.models.experiment import Experiment
from tmll.common.models.output import Output
from tmll.ml.modules.base_module import BaseModule
from tmll.tmll_client import TMLLClient
import pandas as pd
import cxxfilt


@dataclass
class FunctionCall:
    """Represents a function call with timing and hierarchy information."""
    entry_id: str
    function_name: str
    start_time: pd.Timestamp
    end_time: pd.Timestamp
    parent_id: str
    thread_id: str
    children: Optional[List['FunctionCall']] = None
    depth: int = 0

    def __post_init__(self):
        if self.children is None:
            self.children = []

    @property
    def duration_ns(self) -> int:
        """Calculates the total duration of the function call in nanoseconds."""
        return int((self.end_time - self.start_time).total_seconds() * 1e9)

    @property
    def duration_us(self) -> float:
        """Calculates the total duration of the function call in microseconds."""
        return self.duration_ns / 1000.0

    @property
    def self_time_ns(self) -> int:
        """
        Calculates the self-time of the function in nanoseconds.
        This is the total duration minus the duration of its direct children.
        """
        children_time = sum(child.duration_ns for child in self.children or [])
        return max(0, self.duration_ns - children_time)


class CriticalPathAnalysisModule(BaseModule):
    """
    A module for performing critical path analysis on application-level traces.

    This class processes UST (e.g., uftrace) flame chart data to build a call stack
    hierarchy, identifies the longest execution paths (critical paths), and
    provides tools for analysis and visualization.
    """

    def __init__(self, client: TMLLClient, experiment: Experiment,
                 outputs: Optional[List[Output]] = None, **kwargs) -> None:
        """
        Initializes the CriticalPathAnalysisModule.

        :param client: The TMLL client for data communication.
        :param experiment: The experiment containing the trace data to analyze.
        :param outputs: A list of outputs to process. If None, the module will search
                        for outputs related to callstacks or flame charts.
        :param kwargs: Additional keyword arguments for the base module.
        """
        super().__init__(client, experiment)

        self.flamechart: Optional[pd.DataFrame] = None
        self.function_calls: Dict[str, FunctionCall] = {}
        self.root_calls: Dict[str, List[FunctionCall]] = defaultdict(list)
        self.thread_calls: Dict[str, List[FunctionCall]] = defaultdict(list)
        self._analysis_results: Optional[Dict] = None

        self.logger.info(f"Initialized Critical Path Analysis Module for experiment: {experiment.name}")

        outputs = experiment.find_outputs(["callstack", "flame", "chart"])
        self._process(outputs, **kwargs)

    def _process(self, outputs: Optional[List[Output]] = None, **kwargs) -> None:
        """
        Fetches and triggers the processing of flame chart data.

        :param outputs: The outputs to process.
        :param kwargs: Additional processing parameters.
        """
        super()._process(outputs=outputs, **kwargs)

    def _post_process(self, **kwargs) -> None:
        """
        Prepares the raw flame chart data for analysis.

        This involves cleaning the data, demangling function names, and
        triggering the construction of the call hierarchy.
        """
        if self.dataframes is not None:
            self.flamechart = next(iter(self.dataframes.values())).copy()
            self.flamechart = self.flamechart[self.flamechart["label"].notna()]

            def safe_demangle(x):
                try:
                    return cxxfilt.demangle(x)
                except Exception:
                    return x
            self.flamechart["label"] = self.flamechart["label"].apply(safe_demangle)
            self.flamechart["entry_id"] = self.flamechart["entry_id"].astype(int)
            self.flamechart = self.flamechart.drop_duplicates()

            self._build_call_hierarchy()
            self.logger.info(f"Processed {len(self.flamechart)} function calls for critical path analysis.")

    def _build_call_hierarchy(self) -> None:
        """Builds the complete call graph from the processed flame chart data."""
        if self.flamechart is None:
            self.logger.warning("No flame chart data available for hierarchy building.")
            return

        self.logger.info("Building call hierarchy...")
        self.function_calls = {}
        self.root_calls = defaultdict(list)
        self.thread_calls = defaultdict(list)

        sorted_df = self.flamechart.sort_values('timestamp')

        for idx, row in sorted_df.iterrows():
            unique_id = f"{row['entry_id']}_{idx.value}"  # type: ignore

            func_call = FunctionCall(
                entry_id=unique_id,
                function_name=row['label'],
                start_time=idx,  # type: ignore
                end_time=row['end_time'],
                parent_id=str(row['parent_id']),
                thread_id=str(row['entry_name'])
            )
            self.function_calls[unique_id] = func_call
            self.thread_calls[str(row['entry_name'])].append(func_call)

        self._build_temporal_hierarchy()

        for func_call in self.function_calls.values():
            if func_call.children:
                func_call.children.sort(key=lambda x: x.start_time)

        self.logger.info(f"Built hierarchy with {len(self.function_calls)} calls across {len(self.thread_calls)} threads.")

    def _build_temporal_hierarchy(self) -> None:
        """Constructs parent-child relationships based on time-based nesting."""
        for thread_id, calls in self.thread_calls.items():
            if not calls:
                continue

            calls.sort(key=lambda x: x.start_time)
            call_stack: List[FunctionCall] = []

            for call in calls:
                while call_stack and call_stack[-1].end_time <= call.start_time:
                    call_stack.pop()

                if call_stack:
                    parent = call_stack[-1]
                    parent.children.append(call) if parent.children is not None else None
                else:
                    self.root_calls[thread_id].append(call)

                call.depth = len(call_stack)
                call_stack.append(call)

    def get_critical_paths(self, k: int = 1, include_hotspots: bool = False,
                           top_bottlenecks: int = 10, ignore_main: bool = True) -> Dict:
        """
        Performs critical path analysis and returns the results.

        This is the primary public method for analysis. It can find either the single
        longest critical path (when k=1) or the top k longest paths.

        :param k: The number of critical paths to find. Defaults to 1.
        :param include_hotspots: If True, includes a global analysis of the most
                                 time-consuming functions.
        :param top_bottlenecks: The number of bottleneck functions to report for each path.
        :param ignore_main: If True (for k>1), calculations for path duration ignore
                            the 'main' function to focus on application logic.
        :return: A dictionary containing the detailed analysis results. The structure of
                 the dictionary depends on the value of `k`.
        """
        if self.flamechart is None or not self.function_calls:
            self.logger.error("Flame chart data not processed. Cannot perform analysis.")
            return {'error': 'Flame chart data not available or processed.'}

        self.logger.info(f"Starting critical path analysis for top {k} path(s)...")
        try:
            if k == 1:
                results = self._get_single_critical_path(include_hotspots, top_bottlenecks)
            else:
                results = self._get_top_k_critical_paths(k, include_hotspots, top_bottlenecks, ignore_main)

            self._analysis_results = results
            return results
        except Exception as e:
            self.logger.error(f"An unexpected error occurred during analysis: {e}")
            return {'error': str(e)}

    def visualize_critical_paths(self, k: int = 1, top_n_functions: int = 50,
                                 figsize: Optional[Tuple[int, int]] = None, **kwargs):
        """
        Generates and returns a visualization of the critical path(s).

        :param k: The number of top critical paths to visualize.
        :param top_n_functions: The maximum number of functions to display in each timeline.
        :param figsize: The size of the matplotlib figure. If None, it's auto-calculated.
        :param kwargs: Additional keyword arguments for plotting (e.g., dpi).
        """
        analysis_results = self.get_critical_paths(k=k)

        if 'error' in analysis_results or not (
            'critical_path' in analysis_results or
            analysis_results.get('top_k_critical_paths')
        ):
            self.logger.warning("No critical path data available to visualize.")
            return None

        self._plot_critical_paths(analysis_results, k, top_n_functions, figsize, **kwargs)

    def get_function_statistics(self) -> pd.DataFrame:
        """
        Returns a DataFrame with detailed statistics for every function call.

        :return: A pandas DataFrame containing function statistics.
        """
        return self._get_function_statistics()

    def get_hotspot_functions(self, top_n: int = 20) -> pd.DataFrame:
        """
        Identifies the most time-consuming functions across all threads.

        :param top_n: The number of top hotspot functions to return.
        :return: A pandas DataFrame with the hotspot analysis.
        """
        return self._find_hotspot_functions(top_n)

    def _get_single_critical_path(self, include_hotspots: bool, top_bottlenecks: int) -> Dict:
        """
        Finds and formats the single longest critical path.

        :param include_hotspots: Whether to include global hotspot analysis.
        :param top_bottlenecks: Number of bottlenecks to report.
        :return: A dictionary with the analysis results.
        """
        path, duration, thread_id = self._find_global_critical_path()
        if not path:
            self.logger.warning("No critical path could be found.")
            return {'error': 'No critical path found'}

        bottleneck_analysis = self._analyze_bottlenecks(path)
        thread_paths = self._find_critical_path_per_thread()

        results = {
            'summary': {
                'critical_thread': thread_id,
                'total_duration_ns': duration,
                'total_duration_us': duration / 1000,
                'path_length': len(path),
                'num_threads': len(self.thread_calls),
                'total_function_calls': len(self.function_calls)
            },
            'critical_path': {
                'functions': [
                    {
                        'function_name': call.function_name,
                        'duration_ns': call.duration_ns,
                        'duration_us': call.duration_us,
                        'self_time_ns': call.self_time_ns,
                        'start_time': call.start_time,
                        'end_time': call.end_time,
                        'thread_id': call.thread_id,
                        'entry_id': call.entry_id
                    } for call in path
                ]
            },
            'bottlenecks': bottleneck_analysis.get('bottlenecks', [])[:top_bottlenecks],
            'thread_analysis': {
                tid: {'duration_ns': d, 'duration_us': d / 1000, 'path_length': len(p)}
                for tid, (p, d) in thread_paths.items()
            }
        }
        if include_hotspots:
            hotspots = self._find_hotspot_functions(top_n=20)
            if not hotspots.empty:
                results['hotspots'] = hotspots.to_dict('records')

        self.logger.info(f"Single critical path analysis complete. Path length: {len(path)}, "
                         f"Duration: {self._format_time_with_unit(duration)}")
        return results

    def _get_top_k_critical_paths(self, k: int, include_hotspots: bool,
                                  top_bottlenecks: int, ignore_main: bool) -> Dict:
        """
        Finds and formats the top k critical paths using a path deviation algorithm.

        :param k: The number of paths to find.
        :param include_hotspots: Whether to include global hotspot analysis.
        :param top_bottlenecks: Number of bottlenecks to report per path.
        :param ignore_main: Whether to ignore the 'main' function in duration calculations.
        :return: A dictionary with the top-k analysis results.
        """
        initial_paths = []
        for thread_id, root_calls in self.root_calls.items():
            for root_call in root_calls:
                path, duration = self._find_longest_path_with_exclusion(root_call, set())
                if path and len(path) > 1:
                    initial_paths.append({'path': path, 'duration': duration, 'thread_id': thread_id})

        if not initial_paths:
            self.logger.warning("No critical paths could be found.")
            return {'error': 'No critical paths could be found.'}

        final_paths, final_signatures = [], set()
        candidates = sorted(initial_paths, key=lambda p: p['duration'], reverse=True)

        while len(final_paths) < k and candidates:
            best_info = candidates.pop(0)
            path_sig = tuple(call.entry_id for call in best_info['path'])
            if path_sig in final_signatures:
                continue

            final_paths.append(best_info)
            final_signatures.add(path_sig)
            best_path = best_info['path']

            for i in range(len(best_path) - 1):
                deviation_node, prefix = best_path[i], best_path[:i]
                excluded_edges = {(best_path[j].entry_id, best_path[j+1].entry_id) for j in range(i, len(best_path)-1)}
                spur_path, _ = self._find_longest_path_with_exclusion(deviation_node, excluded_edges)

                if spur_path and len(spur_path) > 1:
                    new_path = prefix + spur_path
                    candidates.append({
                        'path': new_path,
                        'duration': new_path[0].duration_ns,
                        'thread_id': best_info['thread_id']
                    })
            candidates.sort(key=lambda p: p['duration'], reverse=True)

        results = self._format_top_k_results(final_paths, k, top_bottlenecks, include_hotspots, ignore_main)
        self.logger.info(f"Top-{k} critical paths analysis complete. Found {len(final_paths)} distinct paths.")
        return results

    def _format_top_k_results(self, final_paths: List[Dict], k: int, top_bottlenecks: int,
                              include_hotspots: bool, ignore_main: bool) -> Dict:
        """Helper to format the output dictionary for top-k analysis."""
        results = {
            'summary': {
                'num_paths_requested': k,
                'num_paths_found': len(final_paths),
                'num_threads': len(self.thread_calls),
                'total_function_calls': len(self.function_calls)
            },
            'top_k_critical_paths': []
        }
        for rank, path_info in enumerate(final_paths, 1):
            path = path_info['path']
            path_no_main = path[1:] if (ignore_main and path and path[0].function_name.lower().startswith('main')) else path
            critical_duration = path_no_main[0].duration_ns if path_no_main else path_info['duration']
            bottlenecks = self._analyze_bottlenecks(path_no_main).get('bottlenecks', [])

            path_details = {
                'rank': rank,
                'thread_id': path_info['thread_id'],
                'critical_duration_ns': critical_duration,
                'critical_duration_formatted': self._format_time_with_unit(critical_duration),
                'total_duration_ns': path_info['duration'],
                'path_length': len(path),
                'functions': [
                    {
                        'function_name': call.function_name,
                        'duration_ns': call.duration_ns,
                        'self_time_ns': call.self_time_ns,
                        'thread_id': call.thread_id,
                        'entry_id': call.entry_id,
                        'start_time': call.start_time,
                        'end_time': call.end_time
                    } for call in path
                ],
                'bottlenecks': bottlenecks[:top_bottlenecks]
            }
            results['top_k_critical_paths'].append(path_details)

        if include_hotspots:
            hotspots = self._find_hotspot_functions(top_n=20)
            if not hotspots.empty:
                results['hotspots'] = hotspots.to_dict('records')
        return results

    def _find_longest_path_with_exclusion(self, node: FunctionCall,
                                          excluded_edges: set) -> Tuple[List[FunctionCall], int]:
        """
        Finds the longest path from a node using DFS, excluding specified edges.

        The duration of the path is defined by the wall-clock time of the starting node,
        as this represents the total time encompassing all sub-calls.

        :param node: The node to start the search from.
        :param excluded_edges: A set of (parent_entry_id, child_entry_id) tuples to exclude.
        :return: A tuple containing the longest path and its duration in nanoseconds.
        """
        if not node.children:
            return [node], node.duration_ns

        max_child_duration = 0
        best_child_path: List[FunctionCall] = []

        for child in node.children:
            if (node.entry_id, child.entry_id) in excluded_edges:
                continue

            child_path, child_duration = self._find_longest_path_with_exclusion(child, excluded_edges)
            if child_duration > max_child_duration:
                max_child_duration = child_duration
                best_child_path = child_path

        return [node] + best_child_path, node.duration_ns

    def _find_critical_path_per_thread(self) -> Dict[str, Tuple[List[FunctionCall], int]]:
        """Finds the single longest critical path for each thread."""
        thread_critical_paths = {}
        for thread_id, root_calls in self.root_calls.items():
            if not root_calls:
                continue

            max_duration = 0
            critical_path: List[FunctionCall] = []

            for root_call in root_calls:
                path, duration = self._find_longest_path_with_exclusion(root_call, set())
                if duration > max_duration:
                    max_duration = duration
                    critical_path = path
            thread_critical_paths[thread_id] = (critical_path, max_duration)
        return thread_critical_paths

    def _find_global_critical_path(self) -> Tuple[List[FunctionCall], int, str]:
        """Finds the single longest critical path across all threads."""
        thread_paths = self._find_critical_path_per_thread()
        max_duration = 0
        global_critical_path: List[FunctionCall] = []
        critical_thread = ""

        for thread_id, (path, duration) in thread_paths.items():
            if duration > max_duration:
                max_duration = duration
                global_critical_path = path
                critical_thread = thread_id
        return global_critical_path, max_duration, critical_thread

    def _analyze_bottlenecks(self, critical_path: List[FunctionCall]) -> Dict:
        """Analyzes a given path to identify functions contributing most to its duration."""
        if not critical_path:
            return {}

        total_duration = sum(call.duration_ns for call in critical_path)
        if total_duration == 0:
            return {'bottlenecks': []}

        function_durations = defaultdict(int)
        function_self_times = defaultdict(int)

        for call in critical_path:
            function_durations[call.function_name] += call.duration_ns
            function_self_times[call.function_name] += call.self_time_ns

        bottleneck_analysis = []
        for func_name, total_dur in sorted(function_durations.items(), key=lambda x: x[1], reverse=True):
            self_time = function_self_times[func_name]
            percentage = (total_dur / total_duration) * 100
            bottleneck_analysis.append({
                'function': func_name,
                'total_duration_ns': total_dur,
                'self_time_ns': self_time,
                'percentage_of_path': percentage
            })
        return {'bottlenecks': bottleneck_analysis}

    def _get_function_statistics(self) -> pd.DataFrame:
        """Computes and returns detailed statistics for all function calls."""
        stats = [{
            'function_name': fc.function_name,
            'thread_id': fc.thread_id,
            'duration_ns': fc.duration_ns,
            'self_time_ns': fc.self_time_ns,
            'num_children': len(fc.children or []),
        } for fc in self.function_calls.values()]
        return pd.DataFrame(stats)

    def _find_hotspot_functions(self, top_n: int = 20) -> pd.DataFrame:
        """Aggregates function statistics to find the most time-consuming functions."""
        stats_df = self._get_function_statistics()
        if stats_df.empty:
            return pd.DataFrame()

        hotspots = stats_df.groupby('function_name').agg({
            'duration_ns': ['sum', 'mean', 'count'],
            'self_time_ns': 'sum'
        }).round(2)
        hotspots.columns = ['_'.join(col).strip() for col in hotspots.columns.values]
        total_time = stats_df['duration_ns'].sum()
        hotspots['percentage_total_time'] = (hotspots['duration_ns_sum'] / total_time * 100).round(2)
        return hotspots.sort_values('duration_ns_sum', ascending=False).head(top_n).reset_index()

    def _plot_critical_paths(self, analysis_results: Dict, k: int, top_n: int,
                             figsize: Optional[Tuple[int, int]], **kwargs):
        """
        Internal plotting function to generate visualizations for one or more paths.

        :param analysis_results: The dictionary from get_critical_paths.
        :param k: The number of paths requested.
        :param top_n: Max number of functions to plot per timeline.
        :param figsize: Figure size.
        :param kwargs: Additional plotting arguments.
        """
        if k == 1:
            paths_data = [analysis_results]
        else:
            paths_data = analysis_results.get('top_k_critical_paths', [])

        num_paths = len(paths_data)
        if num_paths == 0:
            return None

        if figsize is None:
            figsize = (16, 8 * num_paths)  # Auto-size figure

        fig, axes = plt.subplots(num_paths * 2, 1, figsize=figsize,
                                 height_ratios=[3, 1] * num_paths,
                                 dpi=kwargs.get("dpi", 100), squeeze=False)

        for i in range(num_paths):
            path_info = paths_data[i]
            # Reconstruct FunctionCall objects from the analysis dictionary for plotting
            path_functions = path_info.get('critical_path', path_info).get('functions', [])
            if not path_functions:
                continue

            # For k=1, the structure is different, so we get it directly
            critical_path = [FunctionCall(
                entry_id=f['entry_id'], function_name=f['function_name'],
                start_time=f['start_time'], end_time=f['end_time'],
                parent_id="", thread_id=f['thread_id']
            ) for f in path_functions[:top_n]]

            ax1, ax2 = axes[i*2, 0], axes[i*2 + 1, 0]
            self._plot_single_path_timeline(ax1, ax2, critical_path, i + 1, path_info)

        title = f'Top Critical Path Analysis' if num_paths == 1 else f'Top {num_paths} Critical Paths Analysis'
        fig.suptitle(title, fontsize=16, fontweight='bold')
        plt.tight_layout(rect=(0, 0, 1, 0.97))

        plt.show()

    def _plot_single_path_timeline(self, ax1, ax2, path: List[FunctionCall], rank: int, path_info: Dict):
        """Plots the timeline and breakdown for a single critical path on given axes."""
        if not path:
            return

        start_ref = path[0].start_time
        timeline_data = [{
            'function': f"{call.function_name[:60]}{'...' if len(call.function_name) > 60 else ''}",
            'start_us': (call.start_time - start_ref).total_seconds() * 1e6,
            'duration_us': call.duration_us,
            'self_time_us': call.self_time_ns / 1000.0,
        } for call in path]
        for item in timeline_data:
            item['end_us'] = item['start_us'] + item['duration_us']

        colors = plt.get_cmap('plasma')(np.linspace(0.1, 0.9, len(timeline_data)))
        for i, data in enumerate(timeline_data):
            ax1.barh(i, data['duration_us'], left=data['start_us'], height=0.6, color=colors[i], edgecolor='black', lw=0.5)
            ax1.text(data['start_us'] + data['duration_us']/2, i,
                     f"{data['function']} - {self._format_time_with_unit(data['duration_us'] * 1000)}",
                     ha='center', va='center', fontsize=8, bbox=dict(fc='white', alpha=0.8, pad=0.2))
            if i > 0:
                ax1.annotate('', xy=(data['start_us'], i - 0.3), xytext=(data['start_us'], i-1 + 0.3),
                             arrowprops=dict(arrowstyle='->', color='gray', lw=0.7))

        max_time = max(d['end_us'] for d in timeline_data) if timeline_data else 0
        time_factor, time_unit = self._get_best_time_unit_for_range(max_time)
        ax1.set_yticks(range(len(timeline_data)))
        ax1.set_yticklabels([f"Call {j+1}" for j in range(len(timeline_data))])
        ax1.set_xlabel(f'Time ({time_unit}) from start')
        ax1.set_ylabel('Critical Path Sequence')
        ax1.set_title(f'Path #{rank} - Thread: {path_info.get("summary", path_info).get("critical_thread", path_info.get("thread_id"))} '
                      f'- Duration: {self._format_time_with_unit(path[0].duration_ns)}')
        ax1.grid(True, alpha=0.3, axis='x')
        ax1.invert_yaxis()
        if time_factor != 1:
            xticks = ax1.get_xticks()
            ax1.set_xticks(xticks)
            ax1.set_xticklabels([f'{tick * time_factor:.1f}' for tick in xticks])

        # Plot duration breakdown
        functions = [d['function'] for d in timeline_data[:15]]
        durations = [d['duration_us'] for d in timeline_data[:15]]
        x_pos = np.arange(len(functions))
        ax2.bar(x_pos, durations, alpha=0.8, color='teal')
        ax2.set_xticks(x_pos)
        ax2.set_xticklabels(functions, rotation=45, ha='right', fontsize=7)
        ax2.set_ylabel(f'Total Time ({time_unit})')
        ax2.set_title(f'Function Duration Breakdown - Path #{rank}')
        ax2.grid(True, alpha=0.3, axis='y')
        if time_factor != 1:
            yticks = ax2.get_yticks()
            ax2.set_yticks(yticks)
            ax2.set_yticklabels([f'{tick * time_factor:.1f}' for tick in yticks])

    def _format_time_with_unit(self, time_ns: float) -> str:
        """Formats a time in nanoseconds to a human-readable string with units."""
        if time_ns < 1e3:
            return f"{time_ns:.1f}ns"
        if time_ns < 1e6:
            return f"{time_ns/1e3:.1f}μs"
        if time_ns < 1e9:
            return f"{time_ns/1e6:.1f}ms"
        return f"{time_ns/1e9:.2f}s"

    def _get_best_time_unit_for_range(self, max_time_us: float) -> Tuple[float, str]:
        """Determines the best time unit (ns, μs, ms, s) for a given time range."""
        if max_time_us < 1:
            return (1000, "ns")
        if max_time_us < 1_000:
            return (1, "μs")
        if max_time_us < 1_000_000:
            return (0.001, "ms")
        return (1e-6, "s")
